"use strict";exports.id=2444,exports.ids=[2444],exports.modules={40581:(e,t,r)=>{r.d(t,{A:()=>d});var a=r(45512),o=r(46368),i=r(32909),n=r(95606),s=r(79334),l=r(58009),u=r(68578);function d(){let e=(0,s.useRouter)(),[t,r]=(0,l.useState)(""),[d,c]=(0,l.useState)(!1),{data:p}=(0,o.Cv)({limit:1e3}),{data:m}=(0,i.I7)(),h=m?.data,[g]=(0,n.VY)(),y=e=>{let t=e.match(/(\d+)\s*days?/i),r=t?parseInt(t[1]):7;return r>7?7:r},x=async()=>{c(!0);let t=S();try{let r=await fetch("http://82.25.91.135:3005/api/v1/ai",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("accessToken")}`},body:JSON.stringify({model:"gpt-3.5-turbo",messages:[{role:"system",content:"You are a helpful AI fitness assistant."},{role:"user",content:t}]})}),{data:a}=await r.json(),o=w(a);if(!o)throw Error("Failed to parse GPT response into valid JSON.");let i=JSON.stringify(o),n=new FormData;n.append("data",i),n.append("image",p.data[0].image);let s=await g(n).unwrap();console.log(s),e.push(`/workout/add-workout/${s.data._id}`)}catch(e){console.error("Error:",e),u.oR.error("Fail to generate your plan. don't suggest more than 7 days",{position:"top-center",autoClose:2e3})}finally{c(!1)}},w=e=>{try{let t=e.match(/{[\s\S]*}/);if(t)return JSON.parse(t[0]);throw Error("No valid JSON found in GPT response.")}catch(e){return console.error("Error parsing JSON:",e),null}},S=()=>{if(!t||!h)return"User details are missing.";let e=y(t);return`
      - Name: ${h.name}
      - Email: ${h.email}
      - Phone: ${h.phone}
      - Role: ${h.role}
      - Goal: ${t}

Create a workout plan based on the goal. If the goal does not specify a duration, use ${e} days.

      make a workout plan based on the Goal. Check if any days type info given in goal (inputMessage) use that otherwise use 7 days.

      This is available exercise data: ${JSON.stringify(p.data)} ...exercise data can be repeated..use only _id from ${JSON.stringify(p.data)}

      in createdBy value will be ${h.role}

      give me just JSON to save in mongoose based on this schema:
const WorkoutSectionSchema = new Schema<WorkoutSection>({
  duration: { type: Number, required: true },
  exercises: { type: [Schema.Types.ObjectId], ref: 'Exercise', required: true },
});

const DayWorkoutSchema = new Schema<DayWorkout>({
  isCompleted: { type: Boolean, required: true },
  day: { type: Number, required: true },
  warmUp: { type: WorkoutSectionSchema, required: true },
  mainWorkout: { type: WorkoutSectionSchema, required: true },
  coolDown: { type: WorkoutSectionSchema, required: true },
});

const WorkoutPlanSchema = new Schema<IWorkoutPlan>({
  createdBy: { type: String, required: true },
  planName: { type: String, required: true },
  description: { type: String, required: true },
  rating: { type: Number, default: 5 },
  image: { type: String, default: 'https://i.ibb.co.com/fd0nMfrB/fitness.png' },
  workouts: { type: [DayWorkoutSchema], required: true },
})
    `};return(0,a.jsx)("div",{children:(0,a.jsxs)("div",{className:"flex items-center  w-full mx-auto bg-white/10 backdrop-blur-lg rounded-lg px- ",children:[(0,a.jsx)("span",{className:"text-white/70 text-lg pl-4",children:(0,a.jsx)("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,a.jsx)("path",{d:"M14 4.4375C15.3462 4.4375 16.4375 3.34619 16.4375 2H17.5625C17.5625 3.34619 18.6538 4.4375 20 4.4375V5.5625C18.6538 5.5625 17.5625 6.65381 17.5625 8H16.4375C16.4375 6.65381 15.3462 5.5625 14 5.5625V4.4375ZM1 11C4.31371 11 7 8.31371 7 5H9C9 8.31371 11.6863 11 15 11V13C11.6863 13 9 15.6863 9 19H7C7 15.6863 4.31371 13 1 13V11ZM17.25 14C17.25 15.7949 15.7949 17.25 14 17.25V18.75C15.7949 18.75 17.25 20.2051 17.25 22H18.75C18.75 20.2051 20.2051 18.75 22 18.75V17.25C20.2051 17.25 18.75 15.7949 18.75 14H17.25Z",fill:"white"})})}),(0,a.jsx)("input",{type:"text",value:t,onChange:e=>r(e.target.value),onKeyDown:e=>{"Enter"===e.key&&x()},placeholder:"create workout plan...",className:"bg-transparent w-full  text-white placeholder-white/50 outline-none px-2 py-6"}),(0,a.jsx)("button",{onClick:x,className:"text-[18px] font-normal  bg-[#01336F] text-white lg:px-10 px-4 lg:py-6 py-6 rounded-lg ",children:d?(0,a.jsxs)("div",{className:"loader-inner",children:[(0,a.jsx)("div",{className:"loader-block"}),(0,a.jsx)("div",{className:"loader-block"}),(0,a.jsx)("div",{className:"loader-block"}),(0,a.jsx)("div",{className:"loader-block"})]}):(0,a.jsx)("h1",{className:"text-[18px] font-normal  bg-[#01336F] text-white  rounded-r-lg flex items-center justify-center",children:"Enter"})})]})})}},46368:(e,t,r)=>{r.d(t,{Cv:()=>a,XC:()=>o});let{useGetAllExercisesQuery:a,usePostExerciseMutation:o}=r(87659).A.injectEndpoints({endpoints:e=>({getAllExercises:e.query({query:({limit:e})=>{let t=new URLSearchParams;return e&&t.append("limit",e.toString()),`exercise/all-exercise?${t.toString()}`},providesTags:["Exercise"]}),postExercise:e.mutation({query:e=>({url:"/exercise/create-exercise",method:"POST",body:e}),invalidatesTags:["Exercise"]})})})},95606:(e,t,r)=>{r.d(t,{QO:()=>a,VY:()=>o,iK:()=>n,us:()=>i});let{useGetAllWorkOutQuery:a,useCreateWorkPlanMutation:o,useWorkPlanDetailsQuery:i,useUpdateWorkPlanMutation:n}=r(87659).A.injectEndpoints({endpoints:e=>({getAllWorkOut:e.query({query:({limit:e})=>{let t=new URLSearchParams;return e&&t.append("limit",e.toString()),`workout-plan/all-workout-plan?${t.toString()}`},providesTags:["WorkOut"]}),createWorkPlan:e.mutation({query:e=>({url:"/workout-plan/create-workout-plan",method:"POST",body:e}),invalidatesTags:["WorkOut"]}),workPlanDetails:e.query({query:e=>({url:`/workout-plan/workout-plan-details/${e}`,method:"GET",headers:{Authorization:`Bearer ${localStorage.getItem("accessToken")}`}}),providesTags:["WorkOut"]}),updateWorkPlan:e.mutation({query:({id:e,formData:t})=>({url:`/workout-plan/update-workout-plan/${e}`,method:"POST",body:t}),invalidatesTags:["WorkOut"]})})})},70440:(e,t,r)=>{r.r(t),r.d(t,{default:()=>o});var a=r(88077);let o=async e=>[{type:"image/x-icon",sizes:"16x16",url:(0,a.fillMetadataSegment)(".",await e.params,"favicon.ico")+""}]}};